const template = document.createElement('template');

template.innerHTML = `
  <link rel="stylesheet" data-asset="header-styles.css">
  <link rel="stylesheet" data-asset="combined-inline.css">
  <link rel="stylesheet" data-asset="shell-styles.css">
  <header class="hmcts-header-wrapper" data-theme="default">
    <div class="hmcts-header__banner">
      <a class="govuk-skip-link" href="#content">Skip to main content</a>
        <div class="hmcts-header">
          <div class="hmcts-header__container">
            <div class="judicial-header__logo">
              <a href="#" aria-label="GOV.UK">
                <img class="img-responsive" alt="GOV.UK logo" data-asset="assets/images/govuk-crest-jcm.png" width="83">
              </a>
            </div>
          <div class="govuk-header__logo"></div>
          <div class="hmcts-header__logo">
            <a class="hmcts-header__link" aria-label="Manage Cases" href="/" data-title-link>Manage Cases</a>
          </div>
          <div class="hmcts-header__content">
            <nav class="hmcts-header__navigation" aria-label="Account navigation">
              <ul class="hmcts-header__navigation-list">
                <li class="hmcts-header__navigation-item">
                  <a class="hmcts-header__navigation-link" href="#" data-signout-link>Sign out</a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
      <nav class="hmcts-primary-navigation transparent-background" aria-label="Primary navigation">
        <div class="hmcts-primary-navigation__container">
          <div class="govuk-header__logo"></div>
          <div class="hmcts-primary-navigation__nav">
            <nav aria-label="Primary navigation" class="hmcts-primary-navigation transparent-background">
              <ul class="hmcts-primary-navigation__list">
                <li class="hmcts-primary-navigation__item"><a class="hmcts-primary-navigation__link" href="/work/my-work/list">My work</a></li>
                <li class="hmcts-primary-navigation__item"><a class="hmcts-primary-navigation__link" href="/cases">Case list</a></li>
                <li class="hmcts-primary-navigation__item"><a class="hmcts-primary-navigation__link" href="/cases/case-filter">Create case</a></li>
                <li class="hmcts-primary-navigation__item"><a class="hmcts-primary-navigation__link" href="/cases/case-search">Find case</a></li>
                <li class="hmcts-primary-navigation__item"><a class="hmcts-primary-navigation__link" href="/search">Search</a></li>
              </ul>
            </nav>
          </div>
          <div class="hmcts-primary-navigation__search">
            <div class="hmcts-primary-navigation__item">
              <ul class="hmcts-primary-navigation__list">
                <li class="hmcts-primary-navigation__item">
                  <div class="case-reference-container">
                    <form novalidate>
                      <label id="case-reference-search" for="exuiCaseReferenceSearch" class="case-reference-search-label">16-digit case reference:</label>
                      <input id="exuiCaseReferenceSearch" name="exuiCaseReferenceSearch" type="text" spellcheck="false" aria-labelledby="case-reference-search" class="govuk-input">
                      <button class="govuk-button govuk-button--secondary" type="button">Find</button>
                    </form>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </div>
    <div class="hmcts-header__container">
      <div class="govuk-phase-banner">
        <p class="govuk-phase-banner__content">
          <strong class="govuk-tag govuk-phase-banner__content__tag">beta</strong>
          <span class="govuk-phase-banner__text">This is a new service - your <a href="https://www.smartsurvey.co.uk/s/CCDSurvey/" target="_blank" rel="noopener noreferrer" class="govuk-link">feedback<span class="visuallyhidden">(Opens in a new window)</span></a> will help us to improve it.</span>
        </p>
      </div>
    </div>
  </header>
`;

const THEME_DEFS = [
  {
    name: 'judicial',
    title: 'Judicial Case Manager',
    href: '/',
    backgroundColor: '#8d0f0e',
    logo: 'judicial',
    matcher: (roles) => roles.some((role) => /(judge|judiciary|panelmember)/i.test(role))
  },
  {
    name: 'case-manager',
    title: 'Manage Cases',
    href: '/',
    backgroundColor: '#202020',
    logo: 'myhmcts',
    matcher: (roles) => roles.some((role) => /pui-case-manager/i.test(role))
  },
  {
    name: 'default',
    title: 'Manage Cases',
    href: '/',
    backgroundColor: '#202020',
    logo: 'none',
    matcher: () => true
  }
];

const normalizeRoles = (input) => {
  if (!input) return [];
  if (Array.isArray(input)) return input.filter(Boolean);
  if (typeof input === 'string') {
    return input
      .split(/[, ]+/)
      .map((r) => r.trim())
      .filter(Boolean);
  }
  return [];
};

const resolveTheme = (roles = [], explicitName) => {
  const normalizedRoles = normalizeRoles(roles);
  if (explicitName) {
    const byName = THEME_DEFS.find((t) => t.name === explicitName);
    if (byName) return byName;
  }
  return THEME_DEFS.find((t) => t.matcher(normalizedRoles)) || THEME_DEFS[THEME_DEFS.length - 1];
};

const defaultMenuItems = [
  { text: 'My work', href: '/work/my-work/list' },
  { text: 'Case list', href: '/cases' },
  { text: 'Create case', href: '/cases/case-filter' },
  { text: 'Find case', href: '/cases/case-search' },
  { text: 'Search', href: '/search' }
];

const judicialMenuItems = [
  { text: 'My work', href: '/work/my-work/list' },
  { text: 'Case list', href: '/cases' },
  { text: 'Find case', href: '/cases/case-search' },
  { text: 'Search', href: '/search' }
];

class HmctsHeaderShell extends HTMLElement {
  constructor() {
    super();
    // If declarative shadow DOM already provided from SSR, leave it intact.
    if (!this.shadowRoot) {
      const shadow = this.attachShadow({ mode: 'open' });
      shadow.appendChild(template.content.cloneNode(true));
      this._hydrateAssetUrls(shadow);
    }
    this._roles = normalizeRoles(this.dataset.roles);
    this._explicitTheme = this.dataset.theme;
    this.applyTheme();
  }

  static get observedAttributes() {
    return ['data-roles', 'data-theme'];
  }

  attributeChangedCallback(name, _, newValue) {
    if (name === 'data-roles') {
      this._roles = normalizeRoles(newValue);
    }
    if (name === 'data-theme') {
      this._explicitTheme = newValue;
    }
    this.applyTheme();
  }

  set roles(value) {
    this._roles = normalizeRoles(value);
    this.applyTheme();
  }

  get roles() {
    return this._roles;
  }

  set theme(value) {
    this._explicitTheme = value;
    this.applyTheme();
  }

  get theme() {
    return this._explicitTheme;
  }

  connectedCallback() {
    // In case dataset was updated after construction
    if (this.dataset.roles) {
      this._roles = normalizeRoles(this.dataset.roles);
    }
    if (this.dataset.theme) {
      this._explicitTheme = this.dataset.theme;
    }
    this.applyTheme();
  }

  applyTheme() {
    const root = this.shadowRoot;
    if (!root) return;
    const theme = resolveTheme(this._roles, this._explicitTheme);

    const titleLink = root.querySelector('[data-title-link]');
    if (titleLink) {
      titleLink.textContent = theme.title;
      titleLink.setAttribute('href', theme.href);
      titleLink.setAttribute('aria-label', theme.title);
    }

    if (root.host) {
      if (this._settingAttr) return;
      if (root.host.getAttribute('data-theme') !== theme.name) {
        this._settingAttr = true;
        root.host.setAttribute('data-theme', theme.name);
        this._settingAttr = false;
      }
    }

    // Update menu based on theme (judicial removes Create case)
    const menu = theme.name === 'judicial' ? judicialMenuItems : defaultMenuItems;
    const navList = root.querySelector('.hmcts-primary-navigation__list');
    if (navList) {
      navList.innerHTML = '';
      menu.forEach((item) => {
        const li = document.createElement('li');
        li.className = 'hmcts-primary-navigation__item';
        const a = document.createElement('a');
        a.className = 'hmcts-primary-navigation__link';
        a.href = item.href;
        a.textContent = item.text;
        li.appendChild(a);
        navList.appendChild(li);
      });
    }
  }

  _hydrateAssetUrls(shadow) {
    const assetBase = new URL('.', import.meta.url);
    shadow.querySelectorAll('link[data-asset]').forEach((link) => {
      const asset = link.getAttribute('data-asset');
      if (asset) {
        link.setAttribute('href', new URL(asset, assetBase).toString());
      }
    });
    shadow.querySelectorAll('[data-asset]').forEach((el) => {
      const asset = el.getAttribute('data-asset');
      if (asset) {
        el.setAttribute('src', new URL(asset, assetBase).toString());
      }
    });
  }
}

customElements.define('hmcts-header-shell', HmctsHeaderShell);
