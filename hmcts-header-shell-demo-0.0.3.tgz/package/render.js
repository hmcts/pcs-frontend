const THEME_DEFS = [
  {
    name: 'judicial',
    title: 'Judicial Case Manager',
    href: '/',
    backgroundColor: '#8d0f0e',
    logo: 'judicial',
    matcher: (roles) => roles.some((role) => /(judge|judiciary|panelmember)/i.test(role)),
  },
  {
    name: 'case-manager',
    title: 'Manage Cases',
    href: '/',
    backgroundColor: '#202020',
    logo: 'myhmcts',
    matcher: (roles) => roles.some((role) => /pui-case-manager/i.test(role)),
  },
  {
    name: 'default',
    title: 'Manage Cases',
    href: '/',
    backgroundColor: '#202020',
    logo: 'none',
    matcher: () => true,
  },
];

const defaultMenuItems = [
  { text: 'My work', href: '/work/my-work/list' },
  { text: 'Case list', href: '/cases' },
  { text: 'Create case', href: '/cases/case-filter' },
  { text: 'Find case', href: '/cases/case-search' },
  { text: 'Search', href: '/search' },
];

const judicialMenuItems = [
  { text: 'My work', href: '/work/my-work/list' },
  { text: 'Case list', href: '/cases' },
  { text: 'Find case', href: '/cases/case-search' },
  { text: 'Search', href: '/search' },
];

const assets = ['header-styles.css', 'combined-inline.css', 'shell-styles.css'];
const scripts = ['hmcts-header.js'];
const footerScripts = ['hmcts-footer.js'];

const normalizeAssetBase = (assetBase = '/') => {
  const withSlash = assetBase.endsWith('/') ? assetBase : `${assetBase}/`;
  return withSlash.replace(/\\/g, '/');
};

const resolveAsset = (assetBase, asset) => `${assetBase}${asset.replace(/^\//, '')}`;

const normalizeRoles = (input) => {
  if (!input) return [];
  if (Array.isArray(input)) return input.filter(Boolean);
  if (typeof input === 'string') {
    return input
      .split(/[, ]+/)
      .map((r) => r.trim())
      .filter(Boolean);
  }
  return [];
};

const resolveTheme = (roles = [], explicitName) => {
  const normalizedRoles = normalizeRoles(roles);
  if (explicitName) {
    const byName = THEME_DEFS.find((t) => t.name === explicitName);
    if (byName) return byName;
  }
  return THEME_DEFS.find((t) => t.matcher(normalizedRoles)) || THEME_DEFS[THEME_DEFS.length - 1];
};

const renderMenu = (items) =>
  items
    .map(
      (item) =>
        `<li class="hmcts-primary-navigation__item"><a class="hmcts-primary-navigation__link" href="${item.href}">${item.text}</a></li>`
    )
    .join('');

const renderHeaderShell = ({ roles, theme, assetBase } = {}) => {
  const normalizedRoles = normalizeRoles(roles);
  const resolvedTheme = resolveTheme(normalizedRoles, theme);
  const resolvedBase = normalizeAssetBase(assetBase || '/');
  const menu = resolvedTheme.name === 'judicial' ? judicialMenuItems : defaultMenuItems;

  const cssLinks = assets
    .map((asset) => `<link rel="stylesheet" href="${resolveAsset(resolvedBase, asset)}">`)
    .join('\n    ');

  const html = `
<hmcts-header-shell data-roles="${normalizedRoles.join(' ')}" data-theme="${resolvedTheme.name}">
  <template shadowrootmode="open">
    ${cssLinks}
    <header class="hmcts-header-wrapper" data-theme="${resolvedTheme.name}">
      <div class="hmcts-header__banner">
        <a class="govuk-skip-link" href="#content">Skip to main content</a>
        <div class="hmcts-header">
          <div class="hmcts-header__container">
            <div class="judicial-header__logo">
              <a href="${resolvedTheme.href}" aria-label="GOV.UK">
                <img class="img-responsive" alt="GOV.UK logo" src="${resolveAsset(
                  resolvedBase,
                  'assets/images/govuk-crest-jcm.png'
                )}" width="83">
              </a>
            </div>
            <div class="govuk-header__logo"></div>
            <div class="hmcts-header__logo">
              <a class="hmcts-header__link" aria-label="${resolvedTheme.title}" href="${resolvedTheme.href}" data-title-link>${resolvedTheme.title}</a>
            </div>
            <div class="hmcts-header__content">
              <nav class="hmcts-header__navigation" aria-label="Account navigation">
                <ul class="hmcts-header__navigation-list">
                  <li class="hmcts-header__navigation-item">
                    <a class="hmcts-header__navigation-link" href="#" data-signout-link>Sign out</a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
        <nav class="hmcts-primary-navigation transparent-background" aria-label="Primary navigation">
          <div class="hmcts-primary-navigation__container">
            <div class="govuk-header__logo"></div>
            <div class="hmcts-primary-navigation__nav">
              <nav aria-label="Primary navigation" class="hmcts-primary-navigation transparent-background">
                <ul class="hmcts-primary-navigation__list">
                  ${renderMenu(menu)}
                </ul>
              </nav>
            </div>
            <div class="hmcts-primary-navigation__search">
              <div class="hmcts-primary-navigation__item">
                <ul class="hmcts-primary-navigation__list">
                  <li class="hmcts-primary-navigation__item">
                    <div class="case-reference-container">
                      <form novalidate>
                        <label id="case-reference-search" for="exuiCaseReferenceSearch" class="case-reference-search-label">16-digit case reference:</label>
                        <input id="exuiCaseReferenceSearch" name="exuiCaseReferenceSearch" type="text" spellcheck="false" aria-labelledby="case-reference-search" class="govuk-input">
                        <button class="govuk-button govuk-button--secondary" type="button">Find</button>
                      </form>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </nav>
      </div>
      <div class="hmcts-header__container">
        <div class="govuk-phase-banner">
          <p class="govuk-phase-banner__content">
            <strong class="govuk-tag govuk-phase-banner__content__tag">beta</strong>
            <span class="govuk-phase-banner__text">This is a new service - your <a href="https://www.smartsurvey.co.uk/s/CCDSurvey/" target="_blank" rel="noopener noreferrer" class="govuk-link">feedback<span class="visuallyhidden">(Opens in a new window)</span></a> will help us to improve it.</span>
          </p>
        </div>
      </div>
    </header>
  </template>
</hmcts-header-shell>
`.trim();

  return {
    html,
    assets: {
      styles: assets.map((asset) => resolveAsset(resolvedBase, asset)),
      scripts: scripts.map((script) => resolveAsset(resolvedBase, script)),
    },
    theme: resolvedTheme.name,
  };
};

const renderFooterShell = ({ assetBase } = {}) => {
  const resolvedBase = normalizeAssetBase(assetBase || '/');
  const cssLinks = assets
    .map((asset) => `<link rel="stylesheet" href="${resolveAsset(resolvedBase, asset)}">`)
    .join('\n    ');

  const html = `
<hmcts-footer-shell>
  <template shadowrootmode="open">
    ${cssLinks}
    <footer class="govuk-footer" role="contentinfo">
      <div class="govuk-width-container">
        <div class="govuk-footer__meta">
          <div class="govuk-footer__meta-item govuk-footer__meta-item--grow">
            <hr class="govuk-section-break govuk-section-break--l">
            <ul class="hmcts-footer__list hmcts-footer__list--inline">
              <li class="hmcts-footer__list-item"><a class="govuk-footer__link" href="https://manage-case.aat.platform.hmcts.net/accessibility" target="_blank"><span class="visuallyhidden">(Opens in a new window)</span>Accessibility</a></li>
              <li class="hmcts-footer__list-item"><a class="govuk-footer__link" href="https://manage-case.aat.platform.hmcts.net/legacy-terms-and-conditions" target="_blank"><span class="visuallyhidden">(Opens in a new window)</span>Terms and conditions</a></li>
              <li class="hmcts-footer__list-item"><a class="govuk-footer__link" href="https://manage-case.aat.platform.hmcts.net/cookies" target="_blank"><span class="visuallyhidden">(Opens in a new window)</span>Cookies</a></li>
              <li class="hmcts-footer__list-item"><a class="govuk-footer__link" href="https://manage-case.aat.platform.hmcts.net/privacy-policy" target="_blank"><span class="visuallyhidden">(Opens in a new window)</span>Privacy policy</a></li>
              <li class="hmcts-footer__list-item"><a class="govuk-footer__link" href="https://manage-case.aat.platform.hmcts.net/get-help" target="_blank"><span class="visuallyhidden">(Opens in a new window)</span>Get help</a></li>
            </ul>
          </div>
          <div class="govuk-footer__meta-item">
            <a class="govuk-footer__link" href="https://www.nationalarchives.gov.uk/information-management/re-using-public-sector-information/uk-government-licensing-framework/crown-copyright/">
              <svg xmlns="http://www.w3.org/2000/svg" role="presentation" width="125" height="102" fill="#6E777A"><path d="m108.76 55.62-.27-.03-.74-1.97c.35-.44.53-1.14 0-1.49-.72-.28-2.74-2.56-3.34-1.08-.26.09-1.86.18-1.98.47a17.72 17.72 0 0 1-1.9-3.9c.31-1.64 4.72-3.7 4.72-3.7s-1.25-1.78-1.75-2.79c-.22.5-.42.29-.9.5 2.44-4.3 2.96-9.97-.28-14.04-.33-.7-.18-1.63-.5-2.33-.56-.73-.95-2.18-1.95-2.33 0 1.28-.13 2.53.5 3.72.66.82-.92 1.53-1.4.87.93-.1 1.1-.29.77-.82-4.05-.9-6.3 1.92-10.17 2.36-.34 0-.64.12-.83.42-2.38 3.17 2.96 1.01 3.42 3.11-.89.73-1.01.25-1.85.04-1.2.05-2.36.42-.86 1.42-.92 1.43-.87 1.93-2.74 2.05.81 1.13.64 2.76.85 4.04-1.33.24-2.23.87-2.26 2.28-.6.13-1.24-.18-1.66.46-.84-.69-1.8-.81-2.8-.83-.48-.36-1.66-1.2-2.93-1.84l.71-2.62 2.06-1.3-1.08-2.15c2.39-8.11 3.16-8.57 4.37-8.74l.06-.23-4.4-1.4-.08.3c1.1.8 1.47 2.12.96 3.68-1.17-.5-1.84-1.61-1.72-2.6l-.29-.08-1.47 4.85.23.07c.58-.83 1.6-1.3 2.76-1.1-1.36 4.29-7.5 2.95-6.4-.7.78-1.5 2.27-.54 1.55 1.04 3.45-1.2 1.41-6.1-1.53-3.17.97-1.98 1.52-3.53.3-5.44-1.59 1.01-2 2.84-1.69 5.27-1.94-4.4-5.33.13-2.58 2.43-.5-3.27 3.58-1.11.82 1.52-2.63 1.84-5.86-.27-5.95-3.52 1.52.13 2.67 1.02 2.83 2.14h.28l.19-5.54-.35-.01c-.23 1.12-1.47 2.07-3.02 2.1.1-1.7 1.1-3.04 2.37-3.26v-.31h-6.46v.31c1.28.22 2.27 1.55 2.38 3.26-1.56-.03-2.8-.98-3.03-2.1l-.34.01.18 5.55.28-.01c.16-1.12 1.32-2.01 2.83-2.14-.09 3.24-3.32 5.36-5.95 3.52-2.75-2.63 1.32-4.79.82-1.52 2.76-2.3-.64-6.83-2.58-2.43.3-2.43-.1-4.26-1.69-5.27-1.22 1.91-.67 3.46.3 5.44-2.94-2.93-4.97 1.98-1.53 3.17-.71-1.58.77-2.54 1.55-1.04 1.1 3.65-5.04 4.99-6.4.7 1.17-.2 2.18.27 2.76 1.1l.24-.07-1.48-4.85-.3.08c.14.99-.53 2.1-1.71 2.6-.5-1.56-.15-2.89.97-3.69l-.08-.28-4.41 1.4.06.22c1.21.17 1.98.63 4.37 8.74l-1.08 2.15 2.06 1.3.65 2.37.02-.01c0 .03-.01.04-.02.01-5.94 2.75-4.59 4.61-9.15 4.08-.41.93-.8 1.86-1.72 2.5a6.64 6.64 0 0 0-1.67-3.56c-.42-.49-1 .05-1.63.1-1.24 2.67-2.1.26-4.28 1.65.09 1.25.28 2.49.97 3.64a7.83 7.83 0 0 1-4.04-1.3c-4.85 5.36-9.92 10.51-14.07 16.42-2.21 2.9-8.14 1.2-6.58-2.79.72-2.91 4.97-2.29 4.7.6 2.1-2.31.76-4.61-2.46-4.1 2.95-1.26 4.72 1.13 7.38-2.15-2.03.04-3.75-.6-5.78-.13 2.57-1.52 6.09.74 8.27-3.45-1.9.2-3.63.99-5.6 1.28 11.84-11.18.45-11.73 1.9-16.56-.93.78-1.46 1.56-1.03 2.6-2.66-1.1-6.59-.77-7.66-3.96-.26 4.54 1.75 4.22 5.22 5.15-1.6-.19-3.18-.2-4.68-.75.31 2.04 1.87 2.47 3.71 2.28-1.8.98-1.39 3.52.44 4.39-1.17-6.57 8.78-4.32 4.24 1.72-2.11 3.1-5.16 5.42-7.72 8.13-.49-.83-1-1.66-2.11-1.54 1.95 2.23-.25 4.66-.77 6.96-.75 2.84 1.79 5.26 4.5 5.6-1.08 1.27-1.16 2.4-.33 3.44.82-4.18 6.94-3.24 7.52-7.76.1-.53.36-.95.96-1.19-2.76 3.09 3.87 9.62-2.36 10.38-.89.03-1.1.95-.62 1.61-2.57-.13-3.28.84-3.67 3.25l3.25-.84c-1.12 2.9-3.66-.17-3.24 5 1.04-.49 2.02-1.01 2.97-1.6.92 2.9-4.67 1.65-.47 6.28a8.57 8.57 0 0 1 1.95-3.03c-.51 1.46-.4 3.15 1.26 3.8l.22-1.07h.13c.24.96.28 2.3 1.22 2.86.31.12.48.3.59.62.17.54.67.68 1.16.74.62.13.78-.56 1.23-.84.13.76 1.04.89 1.5 1.54.33-3.77-4.72-2.4-3.56-4.9.45 1.52 1.88 1.2 2.88 1.81.4.63 1.34 1.16 1.82.28l1.31.97c-.98-4.47-3.33-1.7-4.8-4.05 1.02.04 2.12 1.55 3.23.52.6.61 1.06 1.32 1.51 2.04a3.29 3.29 0 0 0-1.5-3.32c-1.28-.77-3.02.6-4.12-.95-1.5-1.83-1.45-4.4-.67-6.52.71-1.63 2.7-2.24 3.63-3.78-.26 1.36-.13 3.73 1.43 4.17-.38-2.53 1.44-4.81 1.81-7.26.48-.62.5-1.1.07-1.77-.78-1.26-.99-2.77-1.84-4.01-1.33-1.85-2.97-1.9-.26-3.84-1.64 2.53-.3 1.6 1.12 3.99.26-.8 1.47-1.85-.04-1.85-2.39-1.16 3.1-4.18 4.35-4.25 1.23-.1 2.94.04 3.87-1.16C32.56 55 32 54.83 33 53.7c-.67-.39-1.26-.85-1.38-1.71l-1.85.63c.6-.67 2.37-2.03 2.56-.52.04.84.89 1 1.55 1.2-.48.7-1.28 1.4-.55 2.2.5.54.82 1.54 1.61 1.67l.63-2.31c1.74 1.8-1.75 2.8 3.03 4.43a9.56 9.56 0 0 1-.2-2.93c2.3 1.9-1 3.1 4.3 3.72-.58-.7-.72-1.46-.94-2.24.89.15 1.6.98 2.17 1.61.55.83.95 1.28 2.2.47.06.15.07.34.18.43.56.42.33.93.32 1.49h.15c.74-.74.8-1.58.56-2.5-.5-1.74-2.65-.36-3.4-2.13 1 .68 2.02 1.08 3.13.5.62.59.88 1.01 1.18 1.83.5-1.87-.08-3.78-2.07-3.22-.62.22-.88.17-1.5-.37.92.32 1.54-.15 2.13-.57.13.17.2.35.29.36.56.03.92.36 1.27.77.19-1.6-1.42-2.9-3.04-2.49-.4 1.97-2.07.86-3.4.6-2.04-1.2-3.12-3.47-4.93-4.95a3.6 3.6 0 0 0-3.9-3.83c2-.87 4.39.84 4.54 2.91.08.85.6 1.39 1.14 2.02 6.79-13.5 28.69-17.04 41.26-8.47 1.07.98 2.23 1.77 3.34 2.8.44-1.3.18-2.83 2.12-2.05l.37-.24a1.84 1.84 0 0 1 1.58-2.4v.84c-.5.09-.9.57-.82 1.1.39-.09.74.42.53.75a1 1 0 0 0 1.16-.18l.96.08c-.44 1.04-1.97 1.4-2.84.63.17.23-.58 2.53-.6 2.8a.73.73 0 0 1-.75.54l.38.61c.55-.3 1.32-.28 1.25-1.05.1-.44-.18-2.46.45-2.28.25.77-.23 1.65.34 2.4 1.82-.44 1.02-2.06 3.22-2.48.88-.08 2.72-.5 3.19.36-1.92-.5-4.4.02-4.83 2.19-2 .46-3.68 1.88-5.8 1.88-1.7.09-2.15 2.1-2.22 3.48-.29 1.58-.37 3.22-1.08 4.69-.35.56-.06 1.2.13 1.72.65.34 1.11 2.56 1.2 3.36 0 1.45 2.51 1.93 3.54 2.84.28-1.82-3.2-1.3-2.71-3.85.62 1.69 1.97 2.03 3.45 2.86-.46-1.7-.6-4.53-3-4.18-.93-1.27.42-1.34-.01-2.86.69.21 1.01.45 1.2.87l-.7-.22c.08 1.08 1.02 1.33 1.75 2.07-.12-1.76-.28-2.87-1.94-3.73-.94-.85.14-2.81.08-3.99-.03-.34 2.22-1.45 2.56-1.35 1.67.21 3.41-.05 5.02.36 1.61.5.23-2.95 2.83-1.13-1.88-.55-.74 1.48-2.1 1.59-.94 0-1.75-.08-2.74-.12 3.42 7.52 10.99 5.32 13.07 12.03 1.74-1.52.56-1.5.07-3.09 3.94 2.6-3.66 5.6-.8 10.16-.19-.52 1.6-2.65 1.8-3.08.32-.48.88-.5 1.23-.16l.57-1.17c-1.06-.57.86-3.03 1-3.73.2-.42.65-.62 1-.45l.53-1.46c-1-.27-.25-2.67-.33-3.34-1.4-1.26-2.56-2.84-3.65-4.3l.67-.1c-.07.32.05.68.33.87.48.19 2.33 1.96 2.91 1.54l.3.78c-.47.12-.55.77-.56 1.21.25.2.52.4.76.62.03-.16.01-.87.15-.98.22.29.62.3.87.06.22.12-.06 1.67-.03 1.87.27.3.53.6.77.9-.1-.7.78-3.43-.44-3.57ZM88.93 30.25l.76-.08c-.5-.35-.02-.84.4-.5.98.76-1 2-1.16.58Zm-39.44 7.11-2.07-1.3 1.1-2.2 2.98 1.06-2 2.44Zm6.78-1.7c-3.25.66-3.93-2.88-.67-3.47 3.24-.65 3.93 2.89.67 3.47Zm7.34-.27-3.2-2.24 3.2-2.23 3.2 2.23-3.2 2.24Zm10.19-.99c-.38 2.27-5.5 1.29-5.01-.95.38-2.26 5.5-1.29 5 .95Zm1.92.52 3-1.05 1.09 2.18-2.08 1.31-2.01-2.44Zm24.64-10.39c.6.65.85 1.35.85 2.14-.57-.19-.81-.8-.85-2.14Zm-2.69 4.2c-.79.53-1.5 1.32-2.3.25l-.54.1c1.2-1.83 1.1-1.51 2.84-.36Zm-6.61 6.64c.53.19 1.03.46 1.56-.06-.51 0-.67-.36-.81-.7-.25-1.73 2.6-1.12 3.66-1 2.68 1.62 7.23.6 5.65-3.24 1.24.75.81 2.86-.13 3.68-2.47 1.32-4.82.32-7.29 2.92-.37-1.19-1.8-1.12-2.3.18l-1.05.05c-.08-.68.49-1.18.71-1.83Zm9.33 11.35-.33.42c-2.06-2.32-9-4.99-12-4.56l.05-.53-.02.02 1.14-.72-.98-.8c.01-.11-.62-4.02-.62-4.02l1.72-.05s-.61.7-.64 1.27c.1.07.18.17.24.29.34-.15.71-.86.71-.86l.16 2.32s-.47-.67-.82-.79a.56.56 0 0 1-.13.23c.5 1.53 2.76 1.62 2.77.3-.08-.67-.84-.56-.8.16-1.24-.98.44-2.53 1.12-.97-.08-.9 0-1.41.7-1.85.47.58.4 1.13-.1 2 1.52-1.4 2.1.98.67 1.33.7-1.25-1.31-.86-.57.45.67 1.02 2.3.87 2.88-.24a.62.62 0 0 1-.08-.21c-.58-.1-1.43.37-1.43.37l.8-2.13s.33.91.8 1.2c.1-.08.2-.14.32-.17.09-.56-.48-1.44-.48-1.44l2.64 1.01s-1.05.26-1.38.73c.06.1.1.21.11.33.55.1 1.44-.34 1.44-.34l-.94 2.07s-.28-.9-.77-1.2a.68.68 0 0 1-.21.1 1.64 1.64 0 0 0 1.92 2.07c1.46-.44.3-2.08-.1-.7-.78-1.21 1.34-2.54 1.44-.52.26-.97.6-1.41 1.36-1.53.2.79-.1 1.21-.82 1.8 1.64-.67 1.71 1.57.13 1.45.55-.5.07-1.08-.47-.63-.94.97.82 2.37 2.2 1.67 0-.08.03-.17.07-.25-.35-.23-1.16-.26-1.16-.26l1.7-1.24s-.21.75-.05 1.15c.13-.02.25 0 .37.04.37-.37.39-1.34.39-1.34l1.26 1.56s-3.17 1.45-3.73 1.87l-.88-.1.43 1.24h-.03Zm6.83 6.38c-.4-.03-.73.31-.6.74a.25.25 0 0 1-.11-.04l-1.86-1.26a.3.3 0 0 1-.09-.38c.35-.01.73-.2.68-.61.14.18 2.14 1.23 1.98 1.55Z"></path></svg>
              <br>
              <span>© Crown copyright</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  </template>
</hmcts-footer-shell>
`.trim();

  return {
    html,
    assets: {
      styles: assets.map((asset) => resolveAsset(resolvedBase, asset)),
      scripts: footerScripts.map((script) => resolveAsset(resolvedBase, script)),
    },
  };
};

module.exports = {
  renderHeaderShell,
  renderFooterShell,
  normalizeRoles,
  resolveTheme,
};
